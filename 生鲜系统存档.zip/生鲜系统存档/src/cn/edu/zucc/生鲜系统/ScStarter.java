package cn.edu.zucc.����ϵͳ;

import cn.edu.zucc.����ϵͳ.ui.FrmMain;

public class ScStarter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMain();
	}

}
