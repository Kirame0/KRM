package cn.edu.zucc.����ϵͳ.control;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.����ϵͳ.model.BeanBook;
import cn.edu.zucc.����ϵͳ.util.BaseException;
import cn.edu.zucc.����ϵͳ.util.BusinessException;
import cn.edu.zucc.����ϵͳ.util.DBUtil;
import cn.edu.zucc.����ϵͳ.util.DbException;

public class BookManager {
	public List<BeanBook> searchBook(String keyword,String bookState)throws BaseException{
		List<BeanBook> result=new ArrayList<BeanBook>();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select b.barcode,b.bookname,b.pubid,b.price,b.state,p.publishername " +
					" from beanbook b left outer join beanpublisher p on (b.pubid=p.pubid)" +
					" where  b.state='"+bookState+"' ";
			if(keyword!=null && !"".equals(keyword))
				sql+=" and (b.bookname like ? or b.barcode like ?)";
			sql+=" order by b.barcode";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			if(keyword!=null && !"".equals(keyword)){
				pst.setString(1, "%"+keyword+"%");
				pst.setString(2, "%"+keyword+"%");
				
			}
				
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()){
				BeanBook b=new BeanBook();
				b.setBarcode(rs.getString(1));
				b.setBookname(rs.getString(2));
				b.setPubid(rs.getString(3));
				b.setPrice(rs.getDouble(4));
				b.setState(rs.getString(5));
				b.setPubName(rs.getString(6));
				result.add(b);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return result;
		
	}
	public  void createBook(BeanBook b) throws BaseException{
		
		
		if(b.getBarcode()==null || "".equals(b.getBarcode()) || b.getBarcode().length()>20){
			throw new BusinessException("���������1-20����");
		}
		if(b.getBookname()==null || "".equals(b.getBookname()) || b.getBookname().length()>50){
			throw new BusinessException("ͼ�����Ʊ�����1-50����");
		}
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from BeanBook where barcode=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, b.getBarcode());
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()) throw new BusinessException("�����Ѿ���ռ��");
			rs.close();
			pst.close();
			sql="insert into BeanBook(barcode,bookname,pubid,price,state) values(?,?,?,?,'�ڿ�')";
			pst=conn.prepareStatement(sql);
			pst.setString(1, b.getBarcode());
			pst.setString(2, b.getBookname());
			pst.setString(3, b.getPubid());
			pst.setDouble(4, b.getPrice());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}
	public void modifyBook(BeanBook b) throws BaseException{
		if(b.getBookname()==null || "".equals(b.getBookname()) || b.getBookname().length()>50){
			throw new BusinessException("ͼ�����Ʊ�����1-50����");
		}
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from BeanBook where barcode=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, b.getBarcode());
			java.sql.ResultSet rs=pst.executeQuery();
			if(!rs.next()) throw new BusinessException("ͼ�鲻����");
			rs.close();
			pst.close();
			sql="update BeanBook set bookname=?,pubid=?,price=?,state=? where barcode=?";
			pst=conn.prepareStatement(sql);
			pst.setString(1,b.getBookname());
			pst.setString(2, b.getPubid());
			pst.setDouble(3,b.getPrice());
			pst.setString(4, b.getState());
			pst.setString(5, b.getBarcode());
			pst.execute();
			pst.close();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public BeanBook loadBook(String barcode) throws DbException {
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select b.barcode,b.bookname,b.pubid,b.price,b.state,p.publishername " +
					" from beanbook b left outer join beanpublisher p on (b.pubid=p.pubid)" +
					" where  b.barcode=? ";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,barcode);	
			java.sql.ResultSet rs=pst.executeQuery();
			if(rs.next()){
				BeanBook b=new BeanBook();
				b.setBarcode(rs.getString(1));
				b.setBookname(rs.getString(2));
				b.setPubid(rs.getString(3));
				b.setPrice(rs.getDouble(4));
				b.setState(rs.getString(5));
				b.setPubName(rs.getString(6));
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}
	
	
}
