package cn.edu.zucc.����ϵͳ.util;

public class BusinessException extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}
