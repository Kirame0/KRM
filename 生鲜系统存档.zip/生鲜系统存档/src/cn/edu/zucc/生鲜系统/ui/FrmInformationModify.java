package cn.edu.zucc.����ϵͳ.ui;


import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.edu.zucc.����ϵͳ.control.SystemUserManager;
import cn.edu.zucc.����ϵͳ.util.BaseException;


public class FrmInformationModify extends JDialog implements ActionListener {
	
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnModify = new Button("ȷ��");
	private Button btnOk = new Button("ȡ��");
	private JLabel labelId = new JLabel("�û�ID��");
	private JLabel labelName = new JLabel("�û����ƣ�");
	//private JLabel labeladdress = new JLabel("��ַ��");
	private JLabel labelcount = new JLabel("�˻���");
	
	private JTextField edtId = new JTextField(20);
	private JTextField edtName = new JTextField(20);
	private JTextField edtaddress = new JTextField(20);
	private JTextField edtcount = new JTextField(20);

	
	public FrmInformationModify(JFrame f, String s, boolean b) {
		super(f, s, b);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(btnModify);
		toolBar.add(btnOk);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelId);
		workPane.add(edtId);
		edtId.setEditable(false);
		workPane.add(labelName);
		this.edtName.setText(SystemUserManager.currentUser.getUsername());
		workPane.add(edtName);
		//workPane.add(labeladdress);
		//workPane.add(edtaddress);
		workPane.add(labelcount);
		workPane.add(edtcount);
		edtcount.setEditable(false);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(320, 580);
		// ��Ļ������ʾ
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth()) / 2,
				(int) (height - this.getHeight()) / 2);

		this.validate();
		this.btnModify.addActionListener(this);
		this.btnOk.addActionListener(this);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.btnOk) {
			this.setVisible(false);
			return;
		}
		else if(e.getSource()==this.btnModify){
			String name=this.edtName.getText();
			SystemUserManager.currentUser.setUsername(name);
			this.setVisible(false);
			JOptionPane.showMessageDialog(null, "����ɸ�����Ϣ�޸�", "��ʾ",JOptionPane.INFORMATION_MESSAGE);
			
		}
		
	}
	
	
}
