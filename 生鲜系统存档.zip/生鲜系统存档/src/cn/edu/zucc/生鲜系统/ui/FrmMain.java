package cn.edu.zucc.����ϵͳ.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import cn.edu.zucc.����ϵͳ.control.SystemUserManager;

public class FrmMain extends JFrame implements ActionListener {
	private JMenuBar menubar=new JMenuBar(); 
	
    private JMenu menu_Self=new JMenu("���˹���");
    private JMenu menu_Manager=new JMenu("ϵͳ����");
    private JMenu menu_Vegetable=new JMenu("���ʹ���");
    private JMenu menu_VeUser=new JMenu("����ʳ�Ĺ���");
    private JMenu menu_lend=new JMenu("���Ĺ���");
    private JMenu menu_search=new JMenu("��ѯͳ��");
    private JMenu menu_manager=new JMenu("����Ա����");
    private JMenu menu_user=new JMenu("��ͨ�û�����");
    private JMenu menu_Order=new JMenu("�˵�����");


    
    private JMenuItem  menuItem_SelfInformation=new JMenuItem("�������Ϲ���");
    private JMenuItem  menuItem_AccountManager=new JMenuItem("�˻�������");
    private JMenuItem  menuItem_PwdModify=new JMenuItem("�����޸�");
    private JMenuItem  menuItem_Quit=new JMenuItem("�˳�ϵͳ");
    private JMenuItem  menuItem_L=new JMenuItem("���ص�½����");

    private JMenuItem  menuItem_VegetableName=new JMenuItem("��ʳ����������");
    private JMenuItem  menuItem_Discount=new JMenuItem("���Ż��������");
    private JMenuItem  menuItem_Eva=new JMenuItem("�������������");


    private JMenuItem  menuItem_Cart=new JMenuItem("���ﳵ");
    private JMenuItem  menuItem_PreOrder=new JMenuItem("��������");

    
    private JMenuItem  menuItem_UserManager=new JMenuItem("��ͨ�û�����");
    private JMenuItem  menuItem_ReaderTypeManager=new JMenuItem("�Żݹ���");

    private JMenuItem  menuItem_PublisherManager=new JMenuItem("���ʲ�Ʒ�������");
    private JMenuItem  menuItem_BookManager=new JMenuItem("���ʲ�Ʒ����");
    private JMenuItem  menuItem_Sx=new JMenuItem("���ʲ�Ʒ����2");

    
    private JMenuItem  menuItem_Lend=new JMenuItem("����");
    private JMenuItem  menuItem_Return=new JMenuItem("����");
    
    private JMenuItem  menuItem_BookLendSearch=new JMenuItem("���ʲ�Ʒ�����ѯ");
    private JMenuItem  menuItem_ReaderLendSearch=new JMenuItem("�Ż������ѯ");
    private JMenuItem  menuItem_BookLendStatic=new JMenuItem("�������ͳ��");
    //private JMenuItem  menuItem_ReaderLendStatic=new JMenuItem("");
    
    private JMenuItem  menuItem_Vegetable=new JMenuItem("���ʲ�Ʒ����");
    private JMenuItem  menuItem_DiscountManager=new JMenuItem("�Ż��������");

    
    
	private FrmLogin dlgLogin=null;
	private JPanel statusBar = new JPanel();
	public FrmMain(){
		this.setExtendedState(Frame.MAXIMIZED_BOTH);
		this.setTitle("���ʹ���ϵͳ");
		dlgLogin=new FrmLogin(this,"��½",true);
		dlgLogin.setVisible(true);
	    //���˵�

		
		menu_Self.add(menuItem_SelfInformation);
		menuItem_SelfInformation.addActionListener(this);
		menu_Self.add(menuItem_AccountManager);
		menuItem_AccountManager.addActionListener(this);
		menu_Self.add(menuItem_PwdModify);
		menuItem_PwdModify.addActionListener(this);
		menu_Self.add(menuItem_L);
		menuItem_L.addActionListener(this);
		menu_Self.add(menuItem_Quit);
		menuItem_Quit.addActionListener(this);
		menubar.add(menu_Self);
		 if("����Ա".equals(SystemUserManager.currentUser.getUsertype())){
				menu_Vegetable.add(menuItem_BookManager);
			    menuItem_BookManager.addActionListener(this);
			    menu_Vegetable.add(menuItem_PublisherManager);
				menuItem_PublisherManager.addActionListener(this);
				menubar.add(menu_Vegetable);
				menu_search.add(this.menuItem_BookLendSearch);
				menuItem_BookLendSearch.addActionListener(this);
				menu_search.add(this.menuItem_ReaderLendSearch);
				menuItem_ReaderLendSearch.addActionListener(this);
				menu_search.add(this.menuItem_BookLendStatic);
				menuItem_BookLendStatic.addActionListener(this);
			// menu_search.add(this.menuItem_ReaderLendStatic);
			// menuItem_ReaderLendStatic.addActionListener(this);
		    	menu_Manager.add(menuItem_UserManager);
		    	menuItem_UserManager.addActionListener(this);
		    	menu_Manager.add(menuItem_ReaderTypeManager);
		    	menuItem_ReaderTypeManager.addActionListener(this);
		    	//menu_Manager.add(menuItem_ReaderManager);
		    	//menuItem_ReaderManager.addActionListener(this);
		    	//menu_Manager.add(menuItem_PublisherManager);
		    	//menuItem_PublisherManager.addActionListener(this);
		    	//menu_Manager.add(menuItem_BookManager);
		    	//menuItem_BookManager.addActionListener(this);
		    	menubar.add(menu_Manager);
		    }
	   
		
		menu_VeUser.add(menuItem_VegetableName);
	    menuItem_VegetableName.addActionListener(this);
	    menu_VeUser.add(menuItem_Discount);
	    menuItem_Discount.addActionListener(this);
	    menu_VeUser.add(menuItem_Eva);
	    menuItem_Eva.addActionListener(this);
	    menubar.add(menu_VeUser);
	    
	    menu_Order.add(menuItem_Cart);
	    menuItem_Cart.addActionListener(this);
	    menu_Order.add(menuItem_PreOrder);
	    menuItem_PreOrder.addActionListener(this);
	    menubar.add(menu_Order);
	
	    menu_lend.add(this.menuItem_Lend);
	    menuItem_Lend.addActionListener(this);
	    menu_lend.add(this.menuItem_Return);
	    menuItem_Return.addActionListener(this);
	    //menubar.add(menu_lend);
	  
	    menubar.add(this.menu_search);

		
		
	    if("����Ա".equals(SystemUserManager.currentUser.getUsertype())){
	    	menubar.add(menu_Manager);
	    }
	    if(!"����Ա".equals(SystemUserManager.currentUser.getUsertype())){
	    	menubar.add(menu_user);
	    }
	    
	    this.setJMenuBar(menubar);
	    //״̬��
	    statusBar.setLayout(new FlowLayout(FlowLayout.LEFT));
	    JLabel label=new JLabel("����!"+SystemUserManager.currentUser.getUsername());
	    statusBar.add(label);
	    this.getContentPane().add(statusBar,BorderLayout.SOUTH);
	    this.addWindowListener(new WindowAdapter(){   
	    	public void windowClosing(WindowEvent e){ 
	    		System.exit(0);
             }
        });
	    this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==this.menuItem_UserManager){
			FrmUserManager dlg=new FrmUserManager(this,"�û�����",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_ReaderTypeManager){
			FrmReaderTypeManager dlg=new FrmReaderTypeManager(this,"����������",true);
			dlg.setVisible(true);
		}
		//else if(e.getSource()==this.menuItem_ReaderManager){
			//FrmReaderManager dlg=new FrmReaderManager(this,"���߹���",true);
			//dlg.setVisible(true);
		//}
		else if(e.getSource()==this.menuItem_PublisherManager){
			FrmPublisherManager dlg=new FrmPublisherManager(this,"���ʲ�Ʒ������",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_BookManager){
			FrmBookManager dlg=new FrmBookManager(this,"���ʲ�Ʒ����",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Lend){
			FrmLend dlg=new FrmLend(this,"����",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Return){
			FrmReturn dlg=new FrmReturn(this,"�黹",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_BookLendSearch){
			
		}
		else if(e.getSource()==this.menuItem_ReaderLendSearch){
			 
		}
		else if(e.getSource()==this.menuItem_BookLendStatic){
			 
		}
		//else if(e.getSource()==this.menuItem_ReaderLendStatic){
			 
		
		else if(e.getSource()==this.menuItem_SelfInformation){
			FrmInformation dlg=new FrmInformation(this,"������Ϣ����",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_AccountManager){
			FrmRecharge dlg=new FrmRecharge(this,"�˻�������",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_PwdModify){
			FrmPwdModify dlg=new FrmPwdModify(this,"���������޸�",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_L){
			FrmLogin dlg=new FrmLogin(this,"��¼",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Quit){
			System.exit(0);
		}
		else if(e.getSource()==this.menuItem_VegetableName){
			FrmSortVegetable dlg=new FrmSortVegetable(this,"�������ʲ�Ʒ����",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Eva){
			FrmSortEva dlg=new FrmSortEva(this,"������������",true);
			dlg.setVisible(true);
		}
		else if(e.getSource()==this.menuItem_Discount){
			FrmSortDiscount dlg=new FrmSortDiscount(this,"������������",true);
			dlg.setVisible(true);
		}
	}
}
